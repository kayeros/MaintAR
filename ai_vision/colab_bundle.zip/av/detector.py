"""
Обученный детектор дефектов (YOLO), дополняет мультимодальную модель.

Веса ищутся в VISION_DETECTOR или models/pump_defects.pt. Нужен пакет
ultralytics (pip install ultralytics). Если весов или пакета нет, детектор
молча выключен и сервис работает как раньше.
"""
from __future__ import annotations

import io
import os
from pathlib import Path

HERE = Path(__file__).resolve().parent
_MODEL = None
_TRIED = False
DET_CONF = float(os.getenv("VISION_DETECTOR_CONF", "0.35"))


def weights_path() -> Path | None:
    p = Path(os.getenv("VISION_DETECTOR", HERE / "models" / "pump_defects.pt"))
    return p if p.is_file() else None


def load():
    global _MODEL, _TRIED
    if _TRIED:
        return _MODEL
    _TRIED = True
    w = weights_path()
    if not w:
        return None
    try:
        from ultralytics import YOLO
        _MODEL = YOLO(str(w))
        print(f"[detector] загружен {w.name}, классы: {list(_MODEL.names.values())}")
    except Exception as e:
        print(f"[detector] не загружен: {e}")
        _MODEL = None
    return _MODEL


def available() -> bool:
    return load() is not None


def classes() -> list[str]:
    m = load()
    return list(m.names.values()) if m else []


def detect(jpeg: bytes, conf: float = DET_CONF) -> list[dict]:
    """Находки в формате ответа модели: cls, confidence, box [x,y,w,h] в долях."""
    m = load()
    if m is None:
        return []
    from PIL import Image
    im = Image.open(io.BytesIO(jpeg)).convert("RGB")
    W, H = im.size
    res = m.predict(im, conf=conf, verbose=False, imgsz=640)[0]
    out = []
    for b in res.boxes:
        x1, y1, x2, y2 = (float(v) for v in b.xyxy[0].tolist())
        cls = m.names[int(b.cls)]
        out.append({
            "cls": cls,
            "confidence": round(float(b.conf), 2),
            "box": [x1 / W, y1 / H, (x2 - x1) / W, (y2 - y1) / H],
            "explanation": "Найдено детектором YOLO, обученным на открытых наборах данных.",
            "by": "detector",
        })
    return out
